console.log("Start");
setTimeout(() => {
 console.log("Wait 2 second");
}, 2000);
setTimeout(() => {
 console.log("Wait 0 second");
}, 0);
console.log("Finish");