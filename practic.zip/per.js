let a = 10;
let b = 0;
setTimeout(() => {
    b = 20;
}, 2000);
console.log(a+b);

console.log("this is solution :");
let waitingdata = new 
Promise((resolve,reject)=>{
setTimeout(() => {
    ressolve =(20);
}, 2000);
});
    waitingdata.then((data)=>{
        b = data;
        console.log(a+b);
        
    });


