const express = require('express');
const path = require('path');
const app = express();
const publicpath = path.join(__dirname,'public');

const reqFilter = (req,res,next)=>{
    if(!req.query.age)
    {
        res.sendFile(`${publicpath}/index.html`);
    }
    else if(req.query.age<18)
    {
        res.sendFile(`${publicpath}/age.html`);
    }
    else
    {
        next();
    }
}

app.use(reqFilter);

app.get('/',(req,res)=>{
    res.sendFile(`${publicpath}/profile.html`);
});

app.get('/about',(req,res)=>{
    res.sendFile(`${publicpath}/about.html`);
});

app.get('/profile',(req,res)=>{
    res.sendFile(`${publicpath}/profile.html`);
});

app.listen(4500);

