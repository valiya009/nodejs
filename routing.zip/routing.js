const express = require('express');
const path = require('path');
const app = express();
const publicpath = path.join(__dirname,'public');
const route = express.Router();

const reqFilter = (req,res,next)=>{
    if(!req.query.age)
    {
        res.sendFile(`${publicpath}/index.html`);
    }
    else if(req.query.age<18)
    {
        res.sendFile(`${publicpath}/age.html`);
    }
    else
    {
        next();
    }
}

route.use(reqFilter);

app.get('/',(req,res) => {
    res.sendFile(`${publicpath}/home.html`);
});

app.get('/user',(req,res) => {
    res.sendFile(`${publicpath}/user.html`);
});

route.get('/about',(req,res)=>{
    res.sendFile(`${publicpath}/about.html`);
});
route.get('/contact',(req,res)=>{
    res.sendFile(`${publicpath}/contac.html`);
});

app.use('/',route);
app.listen(5000);